<div class="main-container">
	<div class="pd-ltr-20 xs-pd-20-10">
		<div class="min-height-200px">
        <div class="card-box mb-30">
          <div class="pd-20">
            <h4 class="text-blue h4">General Attendance</h4>
						<section class="content-header">
				<button class="btn btn-primary btn-xs col-lg-12" data-toggle="modal" data-target="#addnewuser"><i class="fa  fa-plus"> </i>  New Administrator</button><br>
				<ol class="breadcrumb">
					<li><a href="#"><i class="fa fa-dashboard"></i> Admin</a></li>
					<li class="active">Administrator</li>
				</ol>
			</section>
          </div>
          <div class="pb-20">
            <table id="datatable" class="checkbox-datatable table nowrap">
              <thead>
                <tr>
                  <th><div class="dt-checkbox">
                      <input type="checkbox" name="select_all" value="1" id="example-select-all">
                      <span class="dt-checkbox-label"></span>
                    </div>
                  </th>
                  <th>#</th>
                  <th>Names</th>
                  <th>Class</th>
                  <th>Start Time</th>
                  <th>End Time</th>
                  <th>Status</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                <tr >
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
    </div>
  </div>
</div>
