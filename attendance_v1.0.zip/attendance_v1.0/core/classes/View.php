<?php
class View
{
	public static function imgSize(){
		include_once 'views/alerts/image_size.php';
	}
}
?>